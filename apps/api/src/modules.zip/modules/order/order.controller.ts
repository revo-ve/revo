import {
    Controller,
    Get,
    Post,
    Patch,
    Body,
    Param,
    Query,
    UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { OrderService } from './order.service';
import {
    TenantGuard,
    TenantId,
    CurrentUser,
    Roles,
    RolesGuard,
} from '../../common/guards';

@Controller('orders')
@UseGuards(AuthGuard('jwt'), TenantGuard)
export class OrderController {
    constructor(private orderService: OrderService) {}

    // ---- List orders (with filters & pagination) ----

    @Get()
    async getOrders(
        @TenantId() tenantId: string,
        @Query('status') status?: string,
        @Query('type') type?: string,
        @Query('tableId') tableId?: string,
        @Query('from') from?: string,
        @Query('to') to?: string,
        @Query('page') page?: string,
        @Query('perPage') perPage?: string,
    ) {
        const result = await this.orderService.getOrders(tenantId, {
            status,
            type,
            tableId,
            from,
            to,
            page: page ? parseInt(page) : undefined,
            perPage: perPage ? parseInt(perPage) : undefined,
        });
        return { success: true, ...result };
    }

    // ---- Active orders (for kitchen/POS view) ----

    @Get('active')
    async getActiveOrders(@TenantId() tenantId: string) {
        const data = await this.orderService.getActiveOrders(tenantId);
        return { success: true, data };
    }

    // ---- Daily summary (for dashboard) ----

    @Get('summary/daily')
    async getDailySummary(
        @TenantId() tenantId: string,
        @Query('date') date?: string,
    ) {
        const data = await this.orderService.getDailySummary(tenantId, date);
        return { success: true, data };
    }

    // ---- Single order ----

    @Get(':id')
    async getOrder(
        @TenantId() tenantId: string,
        @Param('id') id: string,
    ) {
        const data = await this.orderService.getOrderById(tenantId, id);
        return { success: true, data };
    }

    // ---- Create order ----

    @Post()
    async createOrder(
        @TenantId() tenantId: string,
        @CurrentUser('sub') userId: string,
        @Body()
        body: {
            tableId?: string;
            type: string;
            notes?: string;
            items: {
                productId: string;
                quantity: number;
                modifiers?: { modifierId: string }[];
                notes?: string;
            }[];
        },
    ) {
        const data = await this.orderService.createOrder(tenantId, userId, body);
        return { success: true, data };
    }

    // ---- Add items to existing order ----

    @Post(':id/items')
    async addItems(
        @TenantId() tenantId: string,
        @Param('id') orderId: string,
        @Body()
        body: {
            items: {
                productId: string;
                quantity: number;
                modifiers?: { modifierId: string }[];
                notes?: string;
            }[];
        },
    ) {
        const data = await this.orderService.addItems(
            tenantId,
            orderId,
            body.items,
        );
        return { success: true, data };
    }

    // ---- Update order status ----

    @Patch(':id/status')
    async updateStatus(
        @TenantId() tenantId: string,
        @Param('id') orderId: string,
        @Body() body: { status: string },
    ) {
        const data = await this.orderService.updateOrderStatus(
            tenantId,
            orderId,
            body.status,
        );
        return { success: true, data };
    }

    // ---- Update item status ----

    @Patch(':id/items/:itemId/status')
    async updateItemStatus(
        @TenantId() tenantId: string,
        @Param('id') orderId: string,
        @Param('itemId') itemId: string,
        @Body() body: { status: string },
    ) {
        const data = await this.orderService.updateItemStatus(
            tenantId,
            orderId,
            itemId,
            body.status,
        );
        return { success: true, data };
    }

    // ---- Pay order ----

    @Post(':id/pay')
    async payOrder(
        @TenantId() tenantId: string,
        @Param('id') orderId: string,
        @Body()
        body: {
            paymentMethod: string;
            payments?: { method: string; amount: number }[];
        },
    ) {
        const data = await this.orderService.payOrder(tenantId, orderId, body);
        return { success: true, data };
    }

    // ---- Cancel order ----

    @Post(':id/cancel')
    async cancelOrder(
        @TenantId() tenantId: string,
        @Param('id') orderId: string,
        @Body() body: { reason?: string },
    ) {
        const data = await this.orderService.cancelOrder(
            tenantId,
            orderId,
            body.reason,
        );
        return { success: true, data };
    }
}