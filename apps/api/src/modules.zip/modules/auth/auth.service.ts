// ============================================
// REVO — Auth Service (Updated for Dynamic Roles)
// ============================================
// Location: apps/api/src/modules/auth/auth.service.ts
// ============================================

import {
  Injectable,
  UnauthorizedException,
  ConflictException,
  NotFoundException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../../database/prisma.service';

@Injectable()
export class AuthService {
  constructor(
      private prisma: PrismaService,
      private jwt: JwtService,
      private config: ConfigService,
  ) {}

  async register(data: {
    tenantName: string;
    ownerName: string;
    email: string;
    password: string;
    phone?: string;
  }) {
    // Check if email is already used
    const existing = await this.prisma.user.findFirst({
      where: { email: data.email },
    });
    if (existing) {
      throw new ConflictException('Este email ya está registrado');
    }

    // Generate slug from tenant name
    const slug = data.tenantName
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '');

    // Check slug uniqueness
    const slugExists = await this.prisma.tenant.findUnique({
      where: { slug },
    });

    const finalSlug = slugExists ? `${slug}-${Date.now().toString(36)}` : slug;

    const hashedPassword = await bcrypt.hash(data.password, 12);

    // Create tenant + default roles + owner in a transaction
    const result = await this.prisma.$transaction(async (tx) => {
      // 1. Create tenant
      const tenant = await tx.tenant.create({
        data: {
          name: data.tenantName,
          slug: finalSlug,
          phone: data.phone,
        },
      });

      // 2. Create default roles for this tenant
      const allPermissions = await tx.permission.findMany();
      const ownerRole = await this.createDefaultRoles(tx, tenant.id, allPermissions);

      // 3. Create owner user with "Dueño" role
      const user = await tx.user.create({
        data: {
          tenantId: tenant.id,
          email: data.email,
          password: hashedPassword,
          name: data.ownerName,
          roleId: ownerRole.id,
        },
      });

      return { tenant, user };
    });

    return this.generateTokens(result.user);
  }

  // Create default roles for a new tenant
  private async createDefaultRoles(tx: any, tenantId: string, allPermissions: any[]) {
    const permissionMap = new Map(allPermissions.map((p) => [p.code, p.id]));

    const defaultRoles = [
      {
        name: 'Dueño',
        description: 'Control total del negocio',
        color: '#3D4F2F',
        permissions: 'ALL',
      },
      {
        name: 'Administrador',
        description: 'Gestión completa excepto facturación',
        color: '#5F7161',
        permissions: allPermissions
            .filter((p) => p.code !== 'settings:billing')
            .map((p) => p.id),
      },
      {
        name: 'Gerente',
        description: 'Supervisión de operaciones diarias',
        color: '#6B8F71',
        permissions: [
          'dashboard:view',
          'menu:view', 'menu:create', 'menu:edit',
          'tables:view', 'tables:manage', 'tables:change_status',
          'orders:view', 'orders:create', 'orders:edit', 'orders:cancel', 'orders:change_status',
          'pos:access', 'pos:process_payment', 'pos:apply_discount', 'pos:void_item', 'pos:cash_operations',
          'kds:access', 'kds:update_status',
          'reports:view', 'reports:sales', 'reports:products', 'reports:staff',
          'inventory:view', 'inventory:manage', 'inventory:adjust', 'inventory:alerts',
          'users:view',
          'qr:view', 'qr:print',
        ].map((code) => permissionMap.get(code)).filter(Boolean),
      },
      {
        name: 'Cajero',
        description: 'Punto de venta y cobros',
        color: '#D4A574',
        permissions: [
          'dashboard:view',
          'menu:view',
          'tables:view', 'tables:change_status',
          'orders:view', 'orders:create', 'orders:change_status',
          'pos:access', 'pos:process_payment', 'pos:apply_discount', 'pos:open_drawer', 'pos:cash_operations',
          'qr:view',
        ].map((code) => permissionMap.get(code)).filter(Boolean),
      },
      {
        name: 'Mesero',
        description: 'Atención de mesas y pedidos',
        color: '#C8553D',
        isDefault: true,
        permissions: [
          'menu:view',
          'tables:view', 'tables:change_status',
          'orders:view', 'orders:create', 'orders:edit',
        ].map((code) => permissionMap.get(code)).filter(Boolean),
      },
      {
        name: 'Cocina',
        description: 'Preparación de pedidos',
        color: '#8B6914',
        permissions: [
          'menu:view',
          'orders:view',
          'kds:access', 'kds:update_status',
          'inventory:view', 'inventory:alerts',
        ].map((code) => permissionMap.get(code)).filter(Boolean),
      },
    ];

    let ownerRole = null;

    for (const roleDef of defaultRoles) {
      const permissionIds =
          roleDef.permissions === 'ALL'
              ? allPermissions.map((p) => p.id)
              : (roleDef.permissions as string[]);

      const role = await tx.role.create({
        data: {
          tenantId,
          name: roleDef.name,
          description: roleDef.description,
          color: roleDef.color,
          isDefault: (roleDef as any).isDefault || false,
          permissions: {
            create: permissionIds.map((permissionId) => ({ permissionId })),
          },
        },
      });

      if (roleDef.name === 'Dueño') {
        ownerRole = role;
      }
    }

    return ownerRole;
  }

  async login(email: string, password: string) {
    const user = await this.prisma.user.findFirst({
      where: { email, isActive: true },
      include: {
        role: {
          include: {
            permissions: {
              include: { permission: true },
            },
          },
        },
      },
    });

    if (!user) {
      throw new UnauthorizedException('Credenciales inválidas');
    }

    const passwordValid = await bcrypt.compare(password, user.password);
    if (!passwordValid) {
      throw new UnauthorizedException('Credenciales inválidas');
    }

    return this.generateTokens(user);
  }

  async refreshToken(refreshToken: string) {
    const stored = await this.prisma.refreshToken.findUnique({
      where: { token: refreshToken },
    });

    if (!stored || stored.expiresAt < new Date()) {
      throw new UnauthorizedException('Refresh token inválido o expirado');
    }

    const user = await this.prisma.user.findUnique({
      where: { id: stored.userId },
      include: {
        role: {
          include: {
            permissions: {
              include: { permission: true },
            },
          },
        },
      },
    });

    if (!user || !user.isActive) {
      throw new UnauthorizedException('Usuario no encontrado');
    }

    // Rotate refresh token
    await this.prisma.refreshToken.delete({ where: { id: stored.id } });

    return this.generateTokens(user);
  }

  async getProfile(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        tenant: true,
        role: {
          include: {
            permissions: {
              include: { permission: true },
            },
          },
        },
      },
    });

    if (!user) {
      throw new NotFoundException('Usuario no encontrado');
    }

    return {
      id: user.id,
      name: user.name,
      email: user.email,
      role: {
        id: user.role.id,
        name: user.role.name,
        color: user.role.color,
        permissions: user.role.permissions.map((rp) => ({
          code: rp.permission.code,
          name: rp.permission.name,
        })),
      },
      tenant: user.tenant ? { name: user.tenant.name } : null,
    };
  }

  private async generateTokens(user: any) {
    const payload = {
      sub: user.id,
      tenantId: user.tenantId,
    };

    const accessToken = this.jwt.sign(payload);

    // Generate refresh token
    const refreshToken = this.jwt.sign(payload, {
      secret: this.config.get<string>('JWT_REFRESH_SECRET'),
      expiresIn: this.config.get<string>('JWT_REFRESH_EXPIRATION') ?? '7d',
    });

    // Store refresh token
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    await this.prisma.refreshToken.create({
      data: {
        userId: user.id,
        token: refreshToken,
        expiresAt,
      },
    });

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        tenantId: user.tenantId,
        email: user.email,
        name: user.name,
        role: user.role
            ? {
              id: user.role.id,
              name: user.role.name,
              color: user.role.color,
              permissions: user.role.permissions?.map((rp: any) => ({
                code: rp.permission.code,
              })) || [],
            }
            : null,
      },
    };
  }
}