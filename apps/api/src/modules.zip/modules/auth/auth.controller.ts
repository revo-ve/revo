import {Body, Controller, Get, HttpCode, HttpStatus, Post, Req, UseGuards,} from '@nestjs/common';
import {AuthService} from './auth.service';
import {Request} from 'express';
import {TenantGuard} from "../../common/guards";
import {AuthGuard} from "@nestjs/passport";

// User returned from JwtStrategy.validate()
interface AuthRequest extends Request {
  user: { id: string; tenantId: string; email: string; name: string; role: string };
}

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('register')
  async register(
      @Body()
      body: {
        tenantName: string;
        ownerName: string;
        email: string;
        password: string;
        phone?: string;
      },
  ) {
    const result = await this.authService.register(body);
    return { success: true, data: result };
  }

  @Post('login')
  @HttpCode(HttpStatus.OK)
  async login(@Body() body: { email: string; password: string }) {
    const result = await this.authService.login(body.email, body.password);
    return { success: true, data: result };
  }

  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  async refresh(@Body() body: { refreshToken: string }) {
    const result = await this.authService.refreshToken(body.refreshToken);
    return { success: true, data: result };
  }

  @Get('me')
  @UseGuards(AuthGuard('jwt'), TenantGuard)
  async getMe(@Req() req: AuthRequest) {
    return await this.authService.getProfile(req.user.id);
  }
}