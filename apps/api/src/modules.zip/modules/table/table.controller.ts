import {
  Controller,
  Get,
  Post,
  Put,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { TableService } from './table.service';
import { TenantGuard, TenantId, Roles, RolesGuard } from '../../common/guards';

@Controller('tables')
@UseGuards(AuthGuard('jwt'), TenantGuard)
export class TableController {
  constructor(private tableService: TableService) {}

  // ---- Zones ----

  @Get('zones')
  async getZones(@TenantId() tenantId: string) {
    const data = await this.tableService.getZones(tenantId);
    return { success: true, data };
  }

  @Post('zones')
  @UseGuards(RolesGuard)
  @Roles('OWNER' as any, 'ADMIN' as any, 'MANAGER' as any)
  async createZone(
    @TenantId() tenantId: string,
    @Body() body: { name: string; sortOrder?: number },
  ) {
    const data = await this.tableService.createZone(tenantId, body);
    return { success: true, data };
  }

  @Put('zones/:id')
  @UseGuards(RolesGuard)
  @Roles('OWNER' as any, 'ADMIN' as any, 'MANAGER' as any)
  async updateZone(
    @TenantId() tenantId: string,
    @Param('id') id: string,
    @Body() body: { name?: string; sortOrder?: number },
  ) {
    const data = await this.tableService.updateZone(tenantId, id, body);
    return { success: true, data };
  }

  @Delete('zones/:id')
  @UseGuards(RolesGuard)
  @Roles('OWNER' as any, 'ADMIN' as any, 'MANAGER' as any)
  async deleteZone(@TenantId() tenantId: string, @Param('id') id: string) {
    await this.tableService.deleteZone(tenantId, id);
    return { success: true, message: 'Zona eliminada' };
  }

  // ---- Tables ----

  @Get()
  async getTables(
    @TenantId() tenantId: string,
    @Query('zoneId') zoneId?: string,
  ) {
    const data = await this.tableService.getTables(tenantId, zoneId);
    return { success: true, data };
  }

  @Get(':id')
  async getTable(@TenantId() tenantId: string, @Param('id') id: string) {
    const data = await this.tableService.getTableById(tenantId, id);
    return { success: true, data };
  }

  @Post()
  @UseGuards(RolesGuard)
  @Roles('OWNER' as any, 'ADMIN' as any, 'MANAGER' as any)
  async createTable(
    @TenantId() tenantId: string,
    @Body() body: { zoneId?: string; number: string; capacity?: number },
  ) {
    const data = await this.tableService.createTable(tenantId, body);
    return { success: true, data };
  }

  @Put(':id')
  @UseGuards(RolesGuard)
  @Roles('OWNER' as any, 'ADMIN' as any, 'MANAGER' as any)
  async updateTable(
    @TenantId() tenantId: string,
    @Param('id') id: string,
    @Body() body: { zoneId?: string; number?: string; capacity?: number },
  ) {
    const data = await this.tableService.updateTable(tenantId, id, body);
    return { success: true, data };
  }

  @Patch(':id/status')
  async updateStatus(
    @TenantId() tenantId: string,
    @Param('id') id: string,
    @Body() body: { status: string },
  ) {
    const data = await this.tableService.updateTableStatus(tenantId, id, body.status);
    return { success: true, data };
  }

  @Delete(':id')
  @UseGuards(RolesGuard)
  @Roles('OWNER' as any, 'ADMIN' as any, 'MANAGER' as any)
  async deleteTable(@TenantId() tenantId: string, @Param('id') id: string) {
    await this.tableService.deleteTable(tenantId, id);
    return { success: true, message: 'Mesa eliminada' };
  }
}
