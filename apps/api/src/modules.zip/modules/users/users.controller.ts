// ============================================
// REVO — Users Controller (Dynamic Roles)
// ============================================
// Location: apps/api/src/modules/users/users.controller.ts
// ============================================

import {
    Controller,
    Get,
    Post,
    Put,
    Patch,
    Delete,
    Body,
    Param,
    Req,
    UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { UsersService } from './users.service';
import { TenantGuard } from '../../common/guards';
import { PermissionsGuard } from '../auth/guards/permissions.guard';
import { RequirePermissions } from '../auth/decorators/permissions.decorator';

@Controller('users')
@UseGuards(AuthGuard('jwt'), TenantGuard, PermissionsGuard)
export class UsersController {
    constructor(private readonly usersService: UsersService) {}

    @Get()
    @RequirePermissions('users:view')
    getUsers(@Req() req: any) {
        return this.usersService.getUsers(req.user.tenantId);
    }

    @Get('roles')
    @RequirePermissions('users:view')
    getRoles(@Req() req: any) {
        return this.usersService.getRoles(req.user.tenantId);
    }

    @Get(':id')
    @RequirePermissions('users:view')
    getUser(@Req() req: any, @Param('id') id: string) {
        return this.usersService.getUser(req.user.tenantId, id);
    }

    @Post()
    @RequirePermissions('users:create')
    createUser(@Req() req: any, @Body() body: any) {
        return this.usersService.createUser(req.user.tenantId, req.user.sub, body);
    }

    @Put(':id')
    @RequirePermissions('users:edit')
    updateUser(@Req() req: any, @Param('id') id: string, @Body() body: any) {
        return this.usersService.updateUser(
            req.user.tenantId,
            req.user.sub,
            id,
            body,
        );
    }

    @Patch(':id/toggle-status')
    @RequirePermissions('users:edit')
    toggleStatus(@Req() req: any, @Param('id') id: string) {
        return this.usersService.toggleUserStatus(
            req.user.tenantId,
            req.user.sub,
            id,
        );
    }

    @Post(':id/reset-password')
    @RequirePermissions('users:edit')
    resetPassword(@Req() req: any, @Param('id') id: string, @Body() body: { password: string }) {
        return this.usersService.resetPassword(
            req.user.tenantId,
            id,
            body.password,
        );
    }

    @Delete(':id')
    @RequirePermissions('users:delete')
    deleteUser(@Req() req: any, @Param('id') id: string) {
        return this.usersService.deleteUser(
            req.user.tenantId,
            req.user.sub,
            id,
        );
    }
}