// ============================================
// REVO — POS Controller (Fixed)
// ============================================
// Location: apps/api/src/modules/pos/pos.controller.ts
// ============================================

import {
    Controller,
    Get,
    Post,
    Body,
    Param,
    Req,
    UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { PosService } from './pos.service';
import {TenantGuard} from "../../common/guards";

@Controller('pos')
@UseGuards(AuthGuard('jwt'), TenantGuard)
export class PosController {
    constructor(private readonly posService: PosService) {}

    @Get('products')
    getProducts(@Req() req: any) {
        return this.posService.getProductsForPOS(req.user.tenantId);
    }

    @Get('tables')
    getTables(@Req() req: any) {
        return this.posService.getTablesForPOS(req.user.tenantId);
    }

    @Get('open-orders')
    getOpenOrders(@Req() req: any) {
        return this.posService.getOpenOrders(req.user.tenantId);
    }

    @Get('stats')
    getStats(@Req() req: any) {
        return this.posService.getShiftStats(req.user.tenantId);
    }

    @Post('order')
    createOrder(@Req() req: any, @Body() body: any) {
        return this.posService.createQuickOrder(
            req.user.tenantId,
            req.user.sub,
            body,
        );
    }

    @Post('order/:id/settle')
    settleOrder(
        @Req() req: any,
        @Param('id') id: string,
        @Body() body: { paymentMethod: string },
    ) {
        return this.posService.settleOrder(
            req.user.tenantId,
            id,
            body.paymentMethod,
        );
    }
}