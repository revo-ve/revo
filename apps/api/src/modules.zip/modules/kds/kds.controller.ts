// ============================================
// REVO — KDS Controller
// ============================================
// Location: apps/api/src/modules/kds/kds.controller.ts
// ============================================

import {
    Controller,
    Get,
    Post,
    Param,
    Req,
    UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { KdsService } from './kds.service';
import {TenantGuard} from "../../common/guards";

@Controller('kds')
@UseGuards(AuthGuard('jwt'), TenantGuard)
export class KdsController {
    constructor(private readonly kdsService: KdsService) {}

    @Get('orders')
    getKitchenOrders(@Req() req: any) {
        return this.kdsService.getKitchenOrders(req.user.tenantId);
    }

    @Get('stats')
    getStats(@Req() req: any) {
        return this.kdsService.getKitchenStats(req.user.tenantId);
    }

    @Post('item/:id/advance')
    advanceItem(@Req() req: any, @Param('id') id: string) {
        return this.kdsService.advanceItemStatus(req.user.tenantId, id);
    }

    @Post('order/:id/advance-all')
    advanceAll(@Req() req: any, @Param('id') id: string) {
        return this.kdsService.advanceAllItems(req.user.tenantId, id);
    }

    @Post('item/:id/recall')
    recallItem(@Req() req: any, @Param('id') id: string) {
        return this.kdsService.recallItem(req.user.tenantId, id);
    }
}